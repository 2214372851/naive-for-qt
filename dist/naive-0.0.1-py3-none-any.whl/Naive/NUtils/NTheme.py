from enum import Enum


class NTheme(Enum):
    light = 0
    dark = 1
