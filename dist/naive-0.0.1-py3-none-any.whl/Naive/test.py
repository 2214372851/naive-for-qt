

def run():
    print(1)